import os
import zipfile
import tempfile
from flask import Request, jsonify, send_file

def generar_zip(request: Request):
    request_json = request.get_json(silent=True)
    nombre_proyecto = request_json.get("proyecto") if request_json else None

    if not nombre_proyecto:
        return jsonify({"status": "error", "message": "Falta el nombre del proyecto."}), 400

    nombre_base = nombre_proyecto.lower().replace(" ", "_")
    carpeta_proyecto = f"/workspace/data/{nombre_base}"

    if not os.path.exists(carpeta_proyecto):
        return jsonify({"status": "error", "message": f"Carpeta del proyecto no encontrada: {carpeta_proyecto}"}), 404

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as temp_zip:
        with zipfile.ZipFile(temp_zip.name, 'w') as zipf:
            for file in os.listdir(carpeta_proyecto):
                path_file = os.path.join(carpeta_proyecto, file)
                if os.path.isfile(path_file):
                    zipf.write(path_file, arcname=file)

        return send_file(temp_zip.name, as_attachment=True, download_name=f"export_{nombre_base}.zip")
