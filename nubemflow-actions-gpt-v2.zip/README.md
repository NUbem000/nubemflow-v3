# NubemFlow Actions GPT

Repositorio para acciones de integración del entorno GPT NubemFlow.

## Cloud Function: generarZipProyecto
Función para empaquetar un proyecto técnico (contexto, tareas, incidencias, informe) en un `.zip`.

## Despliegue recomendado (1st Gen)
```bash
gcloud functions deploy generarZipProyecto \
  --runtime python310 \
  --trigger-http \
  --entry-point generar_zip \
  --allow-unauthenticated \
  --region europe-west1 \
  --no-gen2
```

## Estructura
- `/openapi/`: definición OpenAPI para conectar con el GPT
- `/cloud_functions/generar_zip_proyecto/`: código y dependencias para la función en Google Cloud
