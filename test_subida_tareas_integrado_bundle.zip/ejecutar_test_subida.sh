#!/bin/bash

echo "🚀 Ejecutando test de subida de tareas a Cloud Function..."
python3 test_subida_tareas_integrado.py

echo ""
echo "📝 Revisa la carpeta de logs en: ~/NubemFlow_v3.0_CloudDeploy/logs/"
