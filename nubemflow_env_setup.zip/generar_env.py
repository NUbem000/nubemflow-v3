import os
from getpass import getpass

VARIABLES = {
    "GIT_USERNAME": "Usuario de GitHub (ej. NUbem000)",
    "GIT_TOKEN": "Token personal de GitHub con permisos 'repo'",
    "GIT_REMOTE_URL": "URL del repositorio GitHub (ej. https://github.com/Nubem000/NubemFlow.git)",
    "JIRA_EMAIL": "Correo usado en JIRA (ej. mauricio.mendez@nubemsystems.es)",
    "JIRA_API_TOKEN": "Token de API JIRA (ver instrucciones abajo)",
    "JIRA_URL": "URL base de JIRA (ej. https://nubemsystems.atlassian.net)",
    "MAIL_SENDER": "Cuenta de Gmail desde la que se enviará (ej. mauricio.mendez@nubemsystems.es)",
    "MAIL_NAME": "Nombre visible del remitente (ej. NubemFlow Notifier)",
    "MAIL_PASSWORD": "Contraseña de aplicación de Gmail (ver instrucciones abajo)",
    "MAIL_SMTP_SERVER": "Servidor SMTP (por defecto: smtp.gmail.com)",
    "MAIL_SMTP_PORT": "Puerto SMTP (por defecto: 587)",
    "FIRESTORE_PROJECT_ID": "ID del proyecto GCP (ej. nubemflow-prod)",
    "FIRESTORE_COLLECTION": "Nombre de la colección Firestore (ej. memoria)"
}

DEFAULTS = {
    "MAIL_SMTP_SERVER": "smtp.gmail.com",
    "MAIL_SMTP_PORT": "587",
    "FIRESTORE_COLLECTION": "memoria"
}

def generar_env():
    print("🛠️ Generador de archivo .env para NubemFlow\n")
    valores = {}
    for var, descripcion in VARIABLES.items():
        if "PASSWORD" in var or "TOKEN" in var:
            valor = getpass(f"🔑 {descripcion}: ")
        else:
            valor = input(f"🔧 {descripcion}: ")
        if not valor.strip() and var in DEFAULTS:
            valor = DEFAULTS[var]
            print(f"   ↪️ Usando valor por defecto: {valor}")
        valores[var] = valor.strip()

    with open(".env", "w") as f:
        for k, v in valores.items():
            f.write(f"{k}={v}\n")

    print("\n✅ Archivo .env generado correctamente en esta carpeta.")

if __name__ == "__main__":
    generar_env()
