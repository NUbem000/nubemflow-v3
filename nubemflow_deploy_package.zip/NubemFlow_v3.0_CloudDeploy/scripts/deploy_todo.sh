#!/bin/bash

echo "🚀 Iniciando despliegue de NubemFlow..."

# 1. Dar permisos de ejecución
chmod +x main.sh
chmod +x main_avanzado_nubemflow_v2.sh
chmod +x main_avanzado_nubemflow_v3_con_email.sh
chmod +x utils/generar_env.py

# 2. Mostrar estructura
echo "📁 Estructura del proyecto:"
tree -L 2 || ls -R

# 3. Ejecutar el script principal avanzado con email
echo "🧠 Ejecutando versión con resumen por correo..."
bash main_avanzado_nubemflow_v3_con_email.sh

echo "✅ Despliegue completo."
