# 📄 CHANGELOG – NubemFlow v3.0 CloudDeploy

## [v3.0] – 2025-04-09
### 🚀 Versión actual (CloudDeploy)
...