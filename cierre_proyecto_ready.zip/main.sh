#!/bin/bash

 echo "🚀 Ejecutando script de cierre del proyecto..."
 python3 main.py
