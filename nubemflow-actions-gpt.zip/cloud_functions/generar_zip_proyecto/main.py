import os
import zipfile
import tempfile
from flask import Flask, request, jsonify, send_file

app = Flask(__name__)

@app.route('/generarZipProyecto', methods=['POST'])
def generar_zip():
    data = request.get_json()
    nombre_proyecto = data.get("proyecto")
    if not nombre_proyecto:
        return jsonify({"status": "error", "message": "Falta el nombre del proyecto."}), 400
    nombre_base = nombre_proyecto.lower().replace(" ", "_")
    carpeta_proyecto = f"/workspace/data/{nombre_base}"
    if not os.path.exists(carpeta_proyecto):
        return jsonify({"status": "error", "message": f"Carpeta del proyecto no encontrada: {carpeta_proyecto}"}), 404
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as temp_zip:
        with zipfile.ZipFile(temp_zip.name, 'w') as zipf:
            for file in os.listdir(carpeta_proyecto):
                path_file = os.path.join(carpeta_proyecto, file)
                if os.path.isfile(path_file):
                    zipf.write(path_file, arcname=file)
        return send_file(temp_zip.name, as_attachment=True, download_name=f"export_{nombre_base}.zip")
