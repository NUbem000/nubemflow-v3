# NubemFlow Actions GPT
Este repositorio contiene los endpoints utilizados por NubemFlow GPT para exportación de proyectos, integración y generación de documentación técnica.

## Cloud Function: generarZipProyecto
Función HTTP para empaquetar un proyecto en un archivo .zip

## OpenAPI
El archivo OpenAPI en `openapi/` permite integrar esta acción directamente en el GPT personalizado desde la opción de "importar desde URL".
