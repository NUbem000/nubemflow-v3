# NubemFlow Actions - generarZipProyecto

## ✅ Descripción
Esta acción genera un archivo `.zip` con la entrega final de un proyecto NubemFlow.

## 📥 Input (POST /generarZipProyecto)
```json
{
  "proyecto": "ResidenciaEstudiantil"
}
```

## 📤 Respuesta esperada
```json
{
  "mensaje": "ZIP generado exitosamente",
  "zip_url": "https://.../entrega_ResidenciaEstudiantil.zip",
  "nombre_archivo": "entrega_ResidenciaEstudiantil_20250414_123000.zip",
  "timestamp": "2025-04-14T12:30:00Z"
}
```

## 🖥️ Uso con curl
```bash
curl -X POST https://REGION.cloudfunctions.net/generarZipProyecto \
  -H "Content-Type: application/json" \
  -d '{"proyecto": "ResidenciaEstudiantil"}'
```

## 🧠 GPT Usage (Action configurada)
Compatible con GPT Actions (OpenAPI 3.1.0)
