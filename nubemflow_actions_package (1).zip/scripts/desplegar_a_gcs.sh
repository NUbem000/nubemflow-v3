#!/bin/bash

# CONFIGURACIÓN
BUCKET_NAME="nubemflow-gpt-actions"
PROJECT_ID="nubemflow-prod"
REGION="europe-west1"

# Ruta local de archivos
OPENAPI_PATH="openapi/generar_zip_proyecto.yaml"
PLUGIN_PATH="ai-plugin.json"

# Login y seteo del proyecto
gcloud auth login
gcloud config set project $PROJECT_ID

# Crear el bucket si no existe
if ! gsutil ls -b gs://$BUCKET_NAME >/dev/null 2>&1; then
  echo "⏳ Creando bucket: gs://$BUCKET_NAME"
  gsutil mb -l $REGION gs://$BUCKET_NAME
else
  echo "✅ Bucket ya existe: gs://$BUCKET_NAME"
fi

# Hacer el bucket público si aún no lo es
gsutil iam ch allUsers:objectViewer gs://$BUCKET_NAME

# Subir archivos
echo "⬆️ Subiendo OpenAPI YAML..."
gsutil cp $OPENAPI_PATH gs://$BUCKET_NAME/openapi/

echo "⬆️ Subiendo ai-plugin.json..."
gsutil cp $PLUGIN_PATH gs://$BUCKET_NAME/

# Mostrar URLs resultantes
echo "🌍 Archivos disponibles en:"
echo "🔗 https://storage.googleapis.com/$BUCKET_NAME/ai-plugin.json"
echo "🔗 https://storage.googleapis.com/$BUCKET_NAME/openapi/generar_zip_proyecto.yaml"
